
//>>>>>>>>>>>>>>>this code edit by haisam<<<<<<<<<<<<<
//>>>>>>>>>>>>>>>>>>program start<<<<<<<<<<<<<<<<<<<<<
//Problem: You need to take an input from the user. Then find out if given number is prime or not. If the number is prime then the program should print "The number is prime.", else "The number is not prime."

int main() {
   int number, i, flag = 0;
   
   // Prompt user for input
   printf("Enter a positive integer: ");
   scanf("%d", &number);
   
   // Check if the number is prime
   for (i = 2; i <= number/2; ++i) {
      if (number % i == 0) {
         flag = 1;
         break;
      }
   }
   
   if (number == 1) {
      printf("1 is prime nor composite.\n");
   } else {
      if (flag == 0)
         printf("%d is a prime number.\n", number);
      else
         printf("%d is not a prime number.\n", number);
   }
   

//>>>>>>>>>>>>>>>>>>>program End<<<<<<<<<<<<<<<<<<<<<<
   return 0;
}

