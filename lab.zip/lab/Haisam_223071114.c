#include <stdio.h>



//>>>>>>>>>>>>>>>>Program start<<<<<<<<<<<<<<<<<<<<
//>>>>>>>>>>>>>>>>code edit by Haisam<<<<<<<<<<<<<<
//Problem: You need take two inputs say number1 and number2 from the user. Then find which number is bigger. If number1  is bigger then print "First number is bigger." If number2 is bigger then "Second number is bigger." Moreover if the two number is equal then you must print "Two number is equal."


int main() {
   float number1, number2;
   
   printf("Enter first number: ");
   scanf("%f", &number1);
   
   printf("Enter second number: ");
   scanf("%f", &number2);
   
   if (number1 > number2) {
      printf("First number is bigger.\n");
   }
	else if (number2 > number1) {
      printf("Second number is bigger.\n");
   }
   else {
      printf("Two number is equal.\n");
   }
   
   
   
//>>>>>>>>>>>>>>>>>program End<<<<<<<<<<<<<<<<<<<<<<
   return 0;
}
