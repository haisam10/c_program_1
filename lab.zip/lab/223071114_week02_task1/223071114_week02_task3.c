#include <stdio.h>

int main() {
    int num_inputs, input_num, sum_inputs = 0;
    float avg_inputs;
    
    printf("Enter the number of integers you want to enter: ");
    scanf("%d", &num_inputs);
    
    for (int i = 1; i <= num_inputs; i++) {
        printf("Enter integer %d: ", i);
        scanf("%d", &input_num);
        sum_inputs += input_num;
    }
    
    avg_inputs = (float)sum_inputs / num_inputs;
    
    printf("Sum: %d\n", sum_inputs);
    printf("Average: %.3f\n", avg_inputs);
    
    return 0;
}
// MD HAISAM HOQUE
// ID= 223071114
// TASK 3
