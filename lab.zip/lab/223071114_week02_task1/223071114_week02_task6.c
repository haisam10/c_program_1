#include <stdio.h>
#include <math.h>

int main() {
	
 float P,R,T,CI;
 printf("enter the principal amount ,rate,time:");
 scanf("%d%d%d",&P,&R,&T);
 
 CI=P*pow((1+R/100),T);
 printf("compound interst=%.3f",CI);
 
 return 0;
}

// MD HAISAM HOQUE
// ID= 223071114
// TASK 6
