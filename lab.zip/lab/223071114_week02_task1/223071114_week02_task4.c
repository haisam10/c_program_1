#include <stdio.h>

int main() {
    int n, prev = 0, curr = 1, next;
    
    printf("Enter the number of terms to print: ");
    scanf("%d", &n);
    
    printf("%d %d ", prev, curr);
    
    for (int i = 3; i <= n; i++) {
        next = prev + curr;
        printf("%d ", next);
        prev = curr;
        curr = next;
    }
    
    return 0;
}
// MD HAISAM HOQUE
// ID= 223071114
// TASK 4
