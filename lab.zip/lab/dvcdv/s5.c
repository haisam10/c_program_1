#include<stdio.h>
int main(){
int n,i=1, temp,sum=0, r;
printf("enter the number :");
scanf("%d",&n);
temp=n;
while(n>0){
    r=n%2;
    n=n/2;
    sum= sum+ (r*i);
    i=i*10;
}
printf("%d",sum);
}
