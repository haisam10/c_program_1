//C program to check whether triangle is valid or not if angles are given.
#include<stdio.h>
int main(){
int a,b,c, sum;
printf("enter the value triangle");


printf("enter the value : A = ");
scanf("%d",&a);

printf("enter the value : B = ");
scanf("%d",&b);

printf("enter the value : C = ");
scanf("%d",&c);

sum=a+b+c;

if (sum== 180 && a>0 && b>0 && c>0){
    printf("Triangle is valid.");
}
else{printf("Triangle is not valid.");}
return 0;
}
