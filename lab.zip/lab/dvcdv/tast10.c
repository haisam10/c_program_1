#include <stdio.h>

int main() {
    int num;
    int digit;
    int count;
    int freq[20] = {0};

    printf("Enter an integer: ");
    scanf("%d", &num);

    while(num != 0) {
        digit = num % 10;
        freq[digit]++;
        num /= 10;
    }

    printf("Frequency of digits in the given integer:\n");
    for(int i = 0; i < 10; i++) {
        if(freq[i] != 0) {
            printf("%d: %d times\n", i, freq[i]);
        }
    }

    return 0;
}

